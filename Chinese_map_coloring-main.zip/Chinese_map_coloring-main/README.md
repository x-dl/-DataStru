# 中国地图着色
使用回溯法对中国地图进行着色。
## 运行环境及依赖库：
python3.7
numpy
matplotlib
opencv-python
## 运行命令
``` python coloring.py China.jpg```
## 运行效果
![image](https://github.com/GuanyunFeng/Chinese_map_coloring/blob/main/coloring.gif)
